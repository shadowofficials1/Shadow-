-- Game list 
 * example
 file - for information 
 Game - for script
 Version - for version if update of game

-- Connected file
* Loader - GameLists 
*  *1*   -    *2*
* this Files is informant for all script 